Part III Project: Analysis of Fast-Scanning Data from ALMA

Author: Benjamin Gill (bjg43@cam.ac.uk, http://bjg43.user.srcf.net/)
Project Supervisor: Prof Richard Hills (http://www.mrao.cam.ac.uk/~richard/ALMA_Scan/)

Date: 14-05-2015

*** README ***

** Requirements **

This project was developed on a computer running Ubuntu 14.10 using C++. In addition to the standard libraries included with the OS, the following were used:

spline.h - a simple cubic spline library by Tino Kluge - included in directory
fftw 3.3.4 - a fourier transform library - http://www.fftw.org/
lapacke - Linear Algebra PACKage for C++ - http://www.netlib.org/lapack/

** Overview **

There are three main programs: convert.cc, smooth.cc and basket.cc. These respectively convert signal data to temperature data, perform edge-removal and perform basket-weaving.

** Input file formats **

In the Data directory, there are some example data files. X8b0c92_X114_map.csv is the output from the temperature conversion. It must be converted from csv to tab-separated (.dat) to be used with smooth.cc and basket.cc, which can be done using ctconvert.sh. smooth.cc and basket.cc will accept any .dat file as long as it has time, x, y, and data columns. The number of lines occupied by the header and the number of channels of data must be manually entered into the source code.

The rest is a set of pre-converted data files to feed into convert.cc (or convert.sh). The format is hard-coded, though there is a parameter in the code to change the number of data streams.

** convert.cc **

This program performs temperature conversion and some initial data analysis. There are five command line parameters: (1) the file to read in, (2) a control character, (3) whether to perform temperature conversion, (4) the number of data points to trim off at the start and (5) the number to trim off the end.

The control character can be:
r - this prints out the raw data to the command line in a gnuplot-friendly format
m - prints out a moving average. The length is a parameter in the code (length).
f - prints the fourier transform
a - prints out the average of each channel of data.

To perform the temperature conversion, convert.sh needs to be run first to produce the data needed for the calibration.

** smooth.cc **

This program performs simple zero-removal. There are three command line parameters: (1) the pattern used, (2) the type of zero-removal to undertake, and (3) the input file.

The pattern can be lissajous (r), or clover-leaf (c).
The zero removal can be none (n), edge (e), plane (p), or centre (c - for circular patterns only).

** basket.cc **

This program performs basket-weaving. There are two command line parameters: (1) what to print, and (2) the input pattern. Other parameters are hard coded.

The print option can be no basket weaving (n), basket woven (r), or the average and standard deviation (s).
The pattern can be circular (c), rectangular (r), or the scans alternately assigned to a coverage (a).

map.gnu takes the output from smooth.cc or basket.cc and produces a gnuplot map.

** Makefile **

The makefile is adapted from one by David MacKay and uses g++.

make basket
will compile basket.cc to produce the executable basket

** Known bugs **

- The code for reading files is very simple and liable to break with non-standard data, and has limited error-correction/sanitisation.
- Entering a data file name longer than that in the code will break convert.cc
