#convert.sh

#!/bin/bash

scan=uid___A002_X8c7b22_X4b

pointing=`echo $scan`_subscan004_PM01_pointing.txt
zero=`echo $scan`_scan001_subscan001_PM01_TP.txt
zero2=`echo $scan`_scan001_subscan002_PM01_TP.txt
ambient=`echo $scan`_scan001_subscan003_PM01_TP.txt
hot=`echo $scan`_scan001_subscan004_PM01_TP.txt
data=`echo $scan`_scan002_subscan001_PM01_TP.txt
sky=`echo $scan`_scan002_subscan002_PM01_TP.txt

echo $scan "conversion"

./read $ambient a > ambav
./read $hot a > hotav
./read $sky a > skyav

echo done
