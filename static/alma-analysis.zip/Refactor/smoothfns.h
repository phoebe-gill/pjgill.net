//smoothfns.h


#include "spline.h"

void find_edge(tempdata &data, double xmin, double xmax, double ymin, double ymax, double datalength, char pattern, vector<unsigned int>& edge_start, vector<unsigned int>& edge_end, vector<unsigned int>& zero_pos, vector<double>& zero_offset)
{
	bool in_edge=false;

	double xewidth=0.05*(xmax-xmin);
	double yewidth=0.05*(ymax-ymin);
	
	double rwidth=0.475*(xmax-xmin);
	double xcentre=(xmax+xmin)/2;
	double ycentre=(xmax+xmin)/2;

	double xlow=xmin+xewidth;
	double xhigh=xmax-xewidth;
	double ylow=ymin+yewidth;
	double yhigh=ymax-yewidth;
	
	double temp;
	
	//first, find the edges
	
	if (pattern =='r')
	{
		for (unsigned int i = 0; i < datalength; i += 1)
		{
			if (in_edge==true && (data.xpos[i] > xlow && data.xpos[i] < xhigh) && (data.ypos[i] > ylow && data.ypos[i] < yhigh))
			{
				//cout << i << endl;
				in_edge=false;
				edge_end.push_back(i);
			}

			if (in_edge==false && (data.xpos[i] < xlow || data.xpos[i] > xhigh || data.ypos[i] < ylow || data.ypos[i] > yhigh))
			{
				//cout << "\t" << i << endl;
				in_edge=true;
				edge_start.push_back(i);
			}
		}
	}
	
	else if (pattern =='c')
	{
		for (unsigned int i = 0; i < datalength; i += 1)
		{
			if (in_edge==true && pow(data.xpos[i]-xcentre,2) + pow(data.ypos[i]-ycentre,2) < pow(rwidth,2) )
			{
				//cout << i << endl;
				in_edge=false;
				edge_end.push_back(i);
			}

			if (in_edge==false && pow(data.xpos[i]-xcentre,2) + pow(data.ypos[i]-ycentre,2) > pow(rwidth,2) )
			{
				//cout << "\t" << i << endl;
				in_edge=true;
				edge_start.push_back(i);
			}
		}
	}

	if(edge_end.size() < edge_start.size()) {edge_end.push_back(datalength-1);}

	//then, find midpoint and average value
	//cout << edge_end.size() << "\t" << edge_start.size() << endl;
	for (unsigned int i = 0; i < edge_end.size(); i += 1)
	{
		temp=0;
		//cout << edge_start.at(i) << endl;
		for (unsigned int j = edge_start[i]; j < edge_end[i] && j < datalength; j += 1)
		{
			temp+=data.value[j];
		}
		zero_offset.push_back(temp/(edge_end[i]-edge_start[i]));
		zero_pos.push_back((edge_end[i]+edge_start[i])*0.5);

		//cout << temp/(edge_end[i]-edge_start[i]) <<"\t" <<(edge_end[i]+edge_start[i])*0.5 << endl;
	}
}

void edge_removal(tempdata &data, double xmin, double xmax, double ymin, double ymax, double datalength, char pattern)
{
	vector<unsigned int> edge_start;
	vector<unsigned int> edge_end;

	vector<unsigned int> zero_pos;
	vector<double> zero_offset;

	double dx,dy,a,b;

	find_edge(data, xmin, xmax, ymin, ymax, datalength, pattern, edge_start, edge_end, zero_pos, zero_offset);

	for (unsigned int i = 0; i < edge_end.size()-1; i += 1)
	{
		//dy=data.value[zero_pos[i+1]]-data.value[zero_pos[i]];
		dy=zero_offset[i+1]-zero_offset[i];
		dx=zero_pos[i+1]-zero_pos[i];

		b=dy/dx;

		a=zero_offset[i] -  zero_pos[i]*b;

		//cout << a <<"\t" <<b << endl;

		for (unsigned int j = zero_pos[i]; j < zero_pos[i+1]; j += 1)
		{
			data.value[j]-=b*j+a;
		}
	}
}
void centre_removal(tempdata &data, double xmin, double xmax, double ymin, double ymax, double datalength, char pattern)
{
	if (pattern == 'r')
		{cout << "Error: incorrect removal method\n";}
		
	vector<unsigned int> edge_start;
	vector<unsigned int> edge_end;

	vector<unsigned int> zero_pos;
	vector<double> zero_offset;
	
	double rwidth=0.01*(xmax-xmin);
	double xcentre=(xmax+xmin)/2;
	double ycentre=(xmax+xmin)/2;

	double temp;
	
	vector<double> tempv;
	
	unsigned int n=0;

	find_edge(data, xmin, xmax, ymin, ymax, datalength, pattern, edge_start, edge_end, zero_pos, zero_offset);
	
	for (unsigned int i = 0; i < edge_end.size()-1; i += 1)
	{
		temp=0;
		n=0;
		for (unsigned int j = zero_pos[i]; j < zero_pos[i+1]; j += 1)
		{
			if (pow(data.xpos[j]-xcentre,2) + pow(data.ypos[j]-ycentre,2) < pow(rwidth,2))
			{
				temp+=data.value[j];
				n++;
			}
		}
		
		if(n==0)
		{
			for (unsigned int j = zero_pos[i]; j < zero_pos[i+1]; j += 1)
			{
				if (pow(data.xpos[j]-xcentre,2) + pow(data.ypos[j]-ycentre,2) < pow(5*rwidth,2))
				{
					temp+=data.value[j];
					n++;
				}
			}	
		}
		
		if(n!=0)
		{
			temp=temp/n;
			
			for (unsigned int j = zero_pos[i]; j < zero_pos[i+1]; j += 1)
			{
				tempv.push_back(data.value[j]-temp );
			}
		}
	}
	
	data.value=tempv;
}

void plane_removal(tempdata &data, double xmin, double xmax, double ymin, double ymax, double datalength, char pattern)
{
	vector<unsigned int> edge_start;
	vector<unsigned int> edge_end;

	vector<unsigned int> zero_pos;
	vector<double> zero_offset;
	
	vector<double> edge_time;
	vector<double> a1, a2, zav;

	double x1,x2,y1,y2,z1,z2, dy,dx,dz; // z = a1*x+a2*y+zav

	tk::spline s1, s2, sz;

	find_edge(data, xmin, xmax, ymin, ymax, datalength, pattern, edge_start, edge_end, zero_pos, zero_offset);

	for (unsigned int i = 0; i < edge_end.size()-1; i += 1)
	{
		y1=data.ypos[zero_pos[i]];
		y2=data.ypos[zero_pos[i+1]];
		dy=y2-y1;
		
		x1=data.xpos[zero_pos[i]];
		x2=data.xpos[zero_pos[i+1]];
		dx=x2-x1;
		
		z1=zero_offset[i];
		z2=zero_offset[i+1];
		zav.push_back((z1+z2)/2);
		dz=z2-z1;
		
		a1.push_back((dx*dz)/(dx*dx+dy*dy));
		a2.push_back((dy*dz)/(dx*dx+dy*dy));
		
		edge_time.push_back((data.time[zero_pos[i+1]]+data.time[zero_pos[i]])*0.5);

	}
	
	s1.set_points(edge_time, a1);
	s2.set_points(edge_time, a2);
	sz.set_points(edge_time, zav);


	for (unsigned int i = 0; i < edge_end.size()-1; i += 1)
	{
		for (unsigned int j = zero_pos[i]; j < zero_pos[i+1]; j += 1)
		{
			data.value[j]-=data.xpos[j]*s1(data.time[j]) + data.ypos[j]*s2(data.time[j]) + sz(data.time[j]);
		}
	}
}
