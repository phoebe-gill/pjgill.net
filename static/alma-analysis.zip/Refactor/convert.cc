//convert.cc - makes data into temperature before processing, now refactored

#include "stddef.h"

#include "stdfns.h"

void t_convert(vector<data>& input, unsigned int datastreams, avdata& T_data)// using previously calculated values, performs the conversion to temperature of the data
{
	unsigned int n;
	
	for (unsigned int i = 0; i < datastreams; i += 1)
	{
		n=input[0].value.size();
		for (unsigned int j = 0; j < n; j += 1)
		{
			input[i].value[j]=(input[i].value[j]/T_data.G[i])-T_data.O[i]-T_data.c[i];
		}
	}
}

int main (int argc, char const* argv[])
{
	unsigned int headerlength=8, datastreams=8;
	string infile ("Data/uid___A002_X8c7b22_X4b_scan002_subscan001_PM01_TP.txt");
	string T1av_infile("ambav");//ambient calibration
	string T2av_infile("hotav");//hot calibration
	string skyav_infile("skyav");//sky calibration
	char control = 'r';
	char convert = 'n';
	unsigned int start=0, end=0, length=1000;//no. to trim at start/end; length of moving average
	double T1=291.05, T2=357.75; // known reference temperatures
	
	metadata meta;
	vector<data> data(datastreams), output(datastreams);
	avdata T_data;
	
	if (argc>1)
		infile = argv[1];
		
	if (argc>2)
		sscanf( argv[2], "%c", &control );
		
	if (argc>3)
		sscanf( argv[2], "%c", &convert );
		
	if (argc>4)
		sscanf( argv[4], "%u", &start );
		
	if (argc>5)
		sscanf( argv[5], "%u", &end );
		
	//comand line help
	if(infile == "help")
	{
		cout << "Usage: " << argv[0] << " <control character> <convert (y/n)> <trim at start> <trim at end>\n See README.txt for more details.\n";
		return 0;
	}	
	
	readin(infile, meta, data, headerlength, datastreams);
	
	//if conversion enabled, perform temperature conversion
	if (convert == 'y')
	{
		T_data.readav(T1av_infile, T2av_infile, skyav_infile, T1, T2, datastreams);
		//readav(T1av_infile, T2av_infile, skyav_infile, T1, T2, T_data, datastreams);
		t_convert(data, datastreams, T_data);
	}
	
	//if we want to trim, do that now.
	trim(start, end, data, datastreams);
	
	//now, do something based on the control caracter
	if (control == 'r')	//raw - do nothing (print raw data)
	{
		print_raw(data, datastreams);
		return 0;
	}
		
	else if (control == 'm') //moving average
	{
		move_av(length, data, output, datastreams);
		print_raw(output, datastreams);
		return 0;		
	}
	
	else if (control == 'f')	//fourier transform
	{
		for (unsigned int i = 0; i < datastreams; i += 1)
		{
			fourier(data[i], output[i]);
		}
		print_raw(output, datastreams);
		return 0;
	}
	
	else if (control == 'a')	//prints average of data - used for obtaining needed values from calibration runs
	{
		for (unsigned int i = 0; i < datastreams; i += 1)
		{
			cout << average(data[i].value) << "\t";
		}
		
		cout << "\n";
	}
	
	else
	{
		cout << control << " is not a valid control character. Please see the readme file for acceptable control characters.\n";
	}
	
	return 0;
}
