// stdfns.h

// takes file name, header length and number of data streams and converts file into internal structures defined by stddef.h
void readin(string infile, metadata& meta, vector<data>& data, unsigned int headerlength, unsigned int datastreams)
{
	unsigned int sample_no;

	string dummy;

	vector <string> header(headerlength,"");
	vector <string> names(datastreams,"");

	vector<int> sample_number;
	
	double dt;
		
	ifstream fin; 
	fin.open(infile.c_str());
	if (fin.is_open()) {;}
	else  {cout << "Error opening file " << infile << endl;}

//Read in, then get metadata into nice format	
	
	for (unsigned int i = 0; i < headerlength; i += 1)
		{getline(fin, header[i]);}
	
	meta.Execblock_UID = header[1].substr(header[1].find_last_of(" ")+1);
	
	meta.BDF_UID = header[2].substr(header[2].find_last_of(" ")+1);
	
	meta.scan_no = atoi(header[3].substr(header[3].find_last_of(" ")+1).c_str());
	
	int tempi=header[4].find_first_of("0123456789");
	meta.subscan_no = atoi( header[4].substr(tempi,header[4].find(' ',tempi)).c_str());
	
	meta.antenna = header[5].substr(header[5].find_last_of(" ")+1);
	
	tempi=header[6].find_first_of("0123456789");
	double tempd = atoi( header[6].substr(tempi,header[6].find(' ',tempi)).c_str());
	if(header[6].find("[s]") !=string::npos) {meta.integration_time = 1.0*tempd;}
	else if(header[6].find("[ms]") !=string::npos) {meta.integration_time = 1.0e-3*tempd;}
	else if(header[6].find("[us]") !=string::npos) {meta.integration_time = 1.0e-6*tempd;}
	else {cout << "Error reading integration duration from " << infile << endl;}
	
//Now for the data labels

	fin >> dummy;//gets rid of # Sample
	fin >> dummy;	
	
	for (unsigned int i = 0; i < datastreams; i += 1)
		{fin >> dummy;
		data[i].name = dummy;}
	
//And the actual data		
	int n=0;
	double temp;
	while (fin >> n)
	{
		//sample_number.push_back(n);
		
		for (unsigned int i = 0; i < datastreams; i += 1)
		{
			fin >> temp;
			data[i].value.push_back(temp);
		}
	}
	
	sample_no=n+1;
	
	for (unsigned int i = 0; i < datastreams; i += 1)
	{
		data[i].point_no=sample_no;
	}
	
	dt = meta.integration_time;
	
	for (unsigned int i = 0; i < sample_no; i += 1)
	{
		temp = i*dt;
		for (unsigned int j = 0; j < datastreams; j += 1)
		{
			data[j].time.push_back(temp);		
		}
	}
	
	fin.close();
}

void avdata::readav(string T1av_infile, string T2av_infile, string skyav_infile, double T1, double T2, unsigned int datastreams)
{
	double temp=0;
	
	T_low=T1;
	T_big=T2;
	
	ifstream fin; 
	fin.open(T1av_infile.c_str());
	if (fin.is_open()) {;}
	else  {cout << "Error opening file " << T1av_infile << endl;}
	
	while (fin >> temp)
	{
		av_low.push_back(temp);
	}
	
	fin.close();
	
	
	fin.open(T2av_infile.c_str());
	if (fin.is_open()) {;}
	else  {cout << "Error opening file " << T2av_infile << endl;}
	
	while (fin >> temp)
	{
		av_big.push_back(temp);
	}
	
	fin.close();
	
	fin.open(skyav_infile.c_str());
	if (fin.is_open()) {;}
	else  {cout << "Error opening file " << skyav_infile << endl;}
	
	while (fin >> temp)
	{
		av_sky.push_back(temp);
	}
	
	fin.close();
	
	for (unsigned int i = 0; i < datastreams; i += 1)
	{
		a.push_back((T_low-T_big)/(av_low[i]-av_big[i]));
		
		b.push_back(T_low - av_low[i]*(T_low-T_big)/(av_low[i]-av_big[i]));
		
		c.push_back(a[i]*av_sky[i]+b[i]);
		G.push_back((av_low[i]-av_big[i])/(T_low-T_big));
		O.push_back((av_low[i]/G[i])-T_low);
	}
}


void print_raw(vector<data>& input, unsigned int datastreams)
{
	printf("Time\t");

	for (unsigned int i = 0; i < datastreams; i += 1)
	{
		cout << input[i].name << "\t";
	}	
	
	for (unsigned int j = 0; j < input[0].point_no; j += 1)
	{
		printf("\n%.10e\t",input[0].time[j]);
		
		for (unsigned int i = 0; i < datastreams; i += 1)
		{
			printf("%e\t",input[i].value[j]);
		}
	}
	cout << endl;
}

/*void print_temp(tempdata input, unsigned int datastreams)
{	
	
	for (unsigned int j = 0; j < 22492; j += 10)
	{
		printf("\n%.10e\t",input.time[j]);
		printf("%e\t",input.xpos[j]);
		printf("%e\t",input.ypos[j]);
		
		for (unsigned int i = 0; i < datastreams; i += 1)
		{
			printf("%e\t",input.value[i][j]);
		}
	}
	cout << endl;
}*/

void trim(unsigned int start, unsigned int finish, vector<data>& data, unsigned int datastreams)
{
	if(start==0 && finish == 0) {return;}//if nothing to trim, end immediately

	for (unsigned int i = 0; i < datastreams; i += 1)
	{
		data[i].time.erase(data[i].time.begin(),data[i].time.begin()+start);
		data[i].time.erase(data[i].time.end()-finish,data[i].time.end());
		
		data[i].value.erase(data[i].value.begin(),data[i].value.begin()+start);
		data[i].value.erase(data[i].value.end()-finish,data[i].value.end());
		
		data[i].point_no-=(start+finish);
	}
}

void move_av(unsigned int length, vector<data>& input, vector<data>& output, unsigned int datastreams)
{
	double temp;

	for (unsigned int i = 0; i < datastreams; i += 1)
	{
		output[i].name=input[i].name;
		output[i].point_no=input[i].point_no-length;
		for (unsigned int j = 0; j < input[i].point_no-length; j += 1)
		{
			temp=input[i].time[j];
			output[i].time.push_back(temp);
			temp=0;
				for (unsigned int k = 0; k < length; k += 1)
				{
					temp+=input[i].value[j+k];
				}
			temp=temp/(length*1.0);
			output[i].value.push_back(temp);
		}
	}
}

void fourier(data input, data &output)
{	
	unsigned int n=input.value.size();
	
	vector<double> fftwinput(2*n,0), fftwoutput(2*n,0);
	
	output.name=input.name;
	output.point_no=input.point_no/2-1;
	
	for (unsigned int i = 0; i < n; i += 1)
	{
		fftwinput[2*i]=input.value[i];
	}

	fftw_complex* finp = (fftw_complex*) &fftwinput[0];
	fftw_complex* fout = (fftw_complex*) &fftwoutput[0];
	
	fftw_plan plan_forward = fftw_plan_dft_1d (n, finp, fout, FFTW_FORWARD, FFTW_ESTIMATE);
	
	fftw_execute ( plan_forward );
	
	fftw_destroy_plan( plan_forward );
	
	for (unsigned int i = 1; i < n/2; i += 1)
	{
		output.value.push_back( pow( pow(fftwoutput[2*i],2) + pow(fftwoutput[2*i+1],2), 0.5) );
		output.time.push_back( i/(input.time[input.point_no-1]-input.time[0]) );
	}
}

void filter(data &input, double centre, double width)
{
	unsigned int n=input.value.size();
	
	for(unsigned int i=0;i<n;i++)
	{
		if(abs(input.time[i]-centre) < width/2)
			{input.value[i]=0;}
	}
}

double average(vector<double>& data)
{
	unsigned int n=data.size();
	double temp=0;

	for (unsigned int i = 0; i < n; i += 1)
	{
		temp+=data[i];
	}
	
	return temp/n;
}

double weighted_average(vector<double>& data, vector<double>& weight)
{
	unsigned int n=weight.size();
	double num=0, dom=0;

	for (unsigned int i = 0; i < n; i += 1)
	{
		num+=data[i]*weight[i];
		dom+=weight[i];
	}
	
	return num/dom;
}

double gaussian_weight(double x1, double x2, double y1, double y2, double width)
{
	return exp( - ( pow(x1-x2,2) + pow(y1-y2,2) )/(0.5*pow(width,2)) );
}

double bessel_weight(double x1, double x2, double y1, double y2, double width)
{
	double r = pow( pow(x1-x2,2) + pow(y1-y2,2) ,0.5);
	
	return j1(2*M_PIl*r/width)*exp( - ( pow(r,2) )/(2*pow(width,2)) )/r ;
}

unsigned int file_length(string infile)
{
	ifstream f(infile.c_str());
	if (f.is_open()) {;}
	else  {cout << "Error opening file " << infile << endl;return -1;}
	char c;
	int m = 0;
	while (f.get(c))
	    if (c == '\n')
		++m;
		
	return m;
}

void vect_grid::init(int M, int N, double xinterval, double yinterval, double xmin, double ymin)
{
	for (unsigned int i = 0; i < M; i += 1)
	{
		for (unsigned int j = 0; j < N; j += 1)
		{
			vw.push_back(0);
			weight.push_back(0);
			value.push_back(0);
			
			xpos.push_back(xmin+i*xinterval);
			ypos.push_back(ymin+j*yinterval);
		}
	}
}
