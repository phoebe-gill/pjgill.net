// smooth.cc - for already converted data in .dat files (from .csv)

#include "stddef.h"

#include "stdfns.h"

#include "smoothfns.h"

int main (int argc, char const* argv[])
{
	unsigned int headerlength=2, datastreams=8;
	string infile ("Data/X8b0c92_X114_map.dat");
	char pattern = 'r'; // r=rectangular, c=circular
	char zero_remove = 'n'; // n=none, e=edge, p=plane, c=centre
	double invR = 20; //~ 1.22 l/D in arcseconds
	double gridsize = 5;
	
	double xmin=0, xmax=0, ymin=0, ymax=0;
	
	unsigned int datalength;
	
	double temp, temp2;
	
	tempdata data;
	
	if (argc>1)
		sscanf( argv[1], "%c", &pattern );
		
	if (argc>2)
		sscanf( argv[2], "%c", &zero_remove );	
		 
	if (argc>3)
		infile=argv[3];
	
	datalength = file_length(infile)-headerlength;
				
	ifstream fin; 
	fin.open(infile.c_str());
	if (fin.is_open()) {;}
	else  {cout << "Error opening file " << infile << endl;}
	
	string dummy;
	
	getline(fin, dummy);
	getline(fin, dummy);
	
	for (unsigned int i = 0; i < datalength; i += 1)
	{
		
		fin >> temp; //to get rid of useless information
		data.time.push_back(temp);
		
		fin >> temp;
		if (temp > xmax)
			{xmax=temp;}
		if (temp < xmin)
			{xmin=temp;}
		data.xpos.push_back(temp);
		
		fin >> temp;
		if (temp > ymax) 
			{ymax=temp;}
		if (temp < ymin)
			{ymin=temp;}
		data.ypos.push_back(temp);
		
		temp2=0;
		for (unsigned int j = 0; j < datastreams; j += 1)
		{
			fin >> temp;
			temp2+=temp;
		}
		data.value.push_back(temp2/datastreams);//average temperature over datastreams
	}
	
	//Now, remove zero fluctuations in data -- rectangular pattern
	
	if (zero_remove == 'e')
		{edge_removal(data, xmin, xmax, ymin, ymax, datalength, pattern);}
	
	else if (zero_remove == 'c')
		{centre_removal(data, xmin, xmax, ymin, ymax, datalength, pattern);}
		
	else if (zero_remove == 'p')
		{plane_removal(data, xmin, xmax, ymin, ymax, datalength, pattern);}
		
	//initialise grid	
	int xgrid = ((xmax-xmin)/gridsize) + 1;
	double xinterval=(xmax-xmin)/xgrid;
	
	int ygrid = ((ymax-ymin)/gridsize) + 1;
	double yinterval=(ymax-ymin)/ygrid;
	
	gridpoint grid[ygrid+1][xgrid+1];
	
	for (int i = 0; i < xgrid+1; i += 1)
	{
		for (int j = 0; j < ygrid+1; j += 1)
		{
			grid[j][i].xpos = xmin+i*xinterval;
			grid[j][i].ypos = ymin+j*yinterval;
			
			grid[j][i].value = 0;
			grid[j][i].weight = 0;
			grid[j][i].vw = 0;
		}
	} 
	
	// Now, regrid with kernel
	int x, y;
	int range=6;
	
	for (unsigned int k = 0; k < data.xpos.size(); k += 1)
	{
		x=(data.xpos[k]-xmin)/xinterval;
		y=(data.ypos[k]-ymin)/yinterval;
		
		
		
		for (int i = max(0,x-range); i < min(xgrid+1,x+range); i += 1)
		{
			for (int j = max(0,y-range); j < min(ygrid+1,y+range); j += 1)
			{
				grid[j][i].value+=data.value[k];
				
				temp=(gaussian_weight(grid[j][i].xpos,data.xpos[k],grid[j][i].ypos,data.ypos[k],invR));
				grid[j][i].weight+=temp;
				grid[j][i].vw+=temp*data.value[k];
			}
		}
	}
	 
	// and finally plot
	
	
	if(pattern == 'r')//if rectangular data
	{
		for (int i = 0; i < ygrid; i += 1)
		{
			for (int j = 0; j < xgrid; j += 1)
			{
				if (grid[j][i].weight >0) //prevents /0 error
				{
					cout << grid[j][i].xpos << "\t" << grid[j][i].ypos << "\t" << grid[j][i].vw/grid[j][i].weight << "\n" ;
				}
			}
		cout << endl;
		}
	}
	
	//or, for circular 
	
	else if (pattern == 'c')
	{
	temp = grid[xgrid/2][ygrid/2].vw/grid[xgrid/2][ygrid/2].weight;//stick something vaguely reasonable at the un-observed corners
	
		for (int i = 0; i < ygrid; i += 1)
		{
			for (int j = 0; j < xgrid; j += 1)
			{
				
				if (grid[j][i].weight > 100)
				{
					cout << grid[j][i].xpos << "\t" << grid[j][i].ypos << "\t" << grid[j][i].vw/grid[j][i].weight << "\n" ;
				}
				
				else
				{
					cout << grid[j][i].xpos << "\t" << grid[j][i].ypos << "\t" << temp << "\n" ;
				}

			}
			cout << endl;
		}
	}
	
	else	{cout << "Error: wrong pattern\n";}

	return 0;
}
