// project.cc - initially, smooth.cc re-implemented in a more sensible manner.

#include <cmath>
#include <iostream>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>
#include <complex.h>
#include <fftw3.h>
#include <assert.h>

#include <algorithm>
#include <functional>

# define M_PIl 3.141592653589793238462643383279502884L /* pi */

using namespace std;

#include <Channel.h>
#include <Dataset.h>

double gaussian_weight(const double distance_sq, const double width)//r^2, width
{
	return exp( - ( distance_sq )/(0.5*pow(width,2)) );
}

double bessel_weight(const double distance_sq, const double width)
{
	double r = pow( distance_sq ,0.5);

	return j1(2*M_PIl*r/width)*exp( - ( distance_sq )/(2*pow(width,2)) )/r ;
}

//modify kernel(,) as appropriate
double kernel(const double distance_sq, const  double width){
	return gaussian_weight(distance_sq, width);
}


/* Under construction
class Map{
private:
	unsigned int _datapoints;
	double _gridsize; //size in arcsec of pixel side
	double _xmin;
	double _ymin;
	unsigned int _M; //pixels in x
	unsigned int _N; //pixels in y
	vector<double> _grid;
	vector<double> _x;
	vector<double> _y;
public:
	void init(Dataset);

	void make(Dataset);
};

void Map::init(Dataset data)
{
	_xmin = data.xmin();
	_ymin = data.ymin();

	_M = (data.xmax() - _xmin)/_gridsize;
	_N = (data.ymax() - _ymin)/_gridsize;

	_datapoints = data.length();
}


void Map::make(Dataset data)
{

}
*/

int main (int argc, char const* argv[])
{
	string infile = "Data/X8b0c92_X114_map.dat";
	Dataset data;
	char control = 'n'; // control character
	unsigned int option1 = 0; //mov_av length or front trim

	//read in command line options if entered
	if (argc>1)
		sscanf( argv[1], "%c", &control );

	if (argc>2)
		sscanf( argv[2], "%u", &option1 );
	
	//for now, assume 8 datastreams and 2 lines of header: data in std format
	const unsigned int datastreams = 8;
	data.init(datastreams);

	const unsigned int header_length = 2;

	data.read(infile, header_length);

	//use average of all datastreams
	data.set_include_all(true);

	data.make();

	switch(control)
	{
	case 'n'://do nothing
		data.print();
	case 'm'://moving average
		data.moving_average(option1);
		data.print();
	case 'f'://fourier transform
		data.fourier();
		data.print_ft();
	default:
		cout << "Invalid control character" << endl;
	}

	return 0;
}
