//basketfns.h

void init_vgrid(int M, int N, double xinterval, double yinterval, double xmin, double ymin, vect_grid &plot)
{
	for (unsigned int i = 0; i < M; i += 1)
	{
		for (unsigned int j = 0; j < N; j += 1)
		{
			plot.vw.push_back(0);
			plot.weight.push_back(0);
			plot.value.push_back(0);
			
			plot.xpos.push_back(xmin+i*xinterval);
			plot.ypos.push_back(ymin+j*yinterval);
		}
	}
}

void fit_vgrid(int M, int N, double xinterval, double yinterval, double xmin, double ymin, vect_grid &plot, int range, tempdata data, double invR)
{
	int x,y;
	double temp=0;
	
	for (unsigned int k = 0; k < data.value.size(); k += 1)
	{
		x=(data.xpos[k]-xmin)/xinterval;
		y=(data.ypos[k]-ymin)/yinterval;
		
		for (unsigned int i = max(0,x-range); i < min(M,x+range); i += 1)
		{
			for (unsigned int j = max(y-range,0); j < min(N,y+range); j += 1)
			{
				temp=gaussian_weight(plot.xpos[j+N*i],data.xpos[k],plot.ypos[j+N*i],data.ypos[k],invR);
				plot.weight[j+N*i]+=temp;
				plot.vw[j+N*i]+=temp*data.value[k];
			}
		}
	}
	
	for (unsigned int i = 0; i < M; i += 1)
	{
		for (unsigned int j = 0; j < N; j += 1)
		{
			if (plot.weight[j+N*i]!=0)
			{
				plot.value[j+N*i]=plot.vw[j+N*i]/plot.weight[j+N*i];
			}
		}
	}
}

void init_A_vgrid(int MNIJ, vector<double>& A)
{
	for (unsigned int i = 0; i < MNIJ; i += 1)
	{
		A.push_back(0);
	}
}

void A_vgrid(int M, int N, double xinterval, double yinterval, double xmin, double ymin, vector<double>& A, vect_grid &plot, int range, tempdata data, double invR, unsigned int offset, unsigned int order)
{

	if(order == 0)
	{
		int x,y;
		double temp=0;
		double MN = M*N;
	
		for (unsigned int k = 0; k < data.value.size(); k += 1)
		{
			x=(data.xpos[k]-xmin)/xinterval;
			y=(data.ypos[k]-ymin)/yinterval;
	
			for (unsigned int i = max(0,x-range); i < min(M,x+range); i += 1)
			{
				for (unsigned int j = max(y-range,0); j <min(N,y+range); j += 1)
				{
					A[j+N*i+offset+MN*data.scan_no[k]]+=gaussian_weight(plot.xpos[j+N*i],data.xpos[k],plot.ypos[j+N*i],data.ypos[k],invR);
				}
			}
		}
	}
	
	if(order == 1)
	{
		int x,y;
		double temp=0;
		double MN = M*N;
		
		for (unsigned int k = 0; k < data.value.size(); k += 1)
		{
			x=(data.xpos[k]-xmin)/xinterval;
			y=(data.ypos[k]-ymin)/yinterval;
	
			for (unsigned int i = max(0,x-range); i < min(M,x+range); i += 1)
			{
				for (unsigned int j = max(y-range,0); j <min(N,y+range); j += 1)
				{
					A[2*(j+N*i+offset+MN*data.scan_no[k])]+=gaussian_weight(plot.xpos[j+N*i],data.xpos[k],plot.ypos[j+N*i],data.ypos[k],invR);
					A[2*(j+N*i+offset+MN*data.scan_no[k])+1]+=gaussian_weight(plot.xpos[j+N*i],data.xpos[k],plot.ypos[j+N*i],data.ypos[k],invR)*(data.pos_in_scan[k]/data.scan_size[data.scan_no[k]]);
				}
			}
		}
	}
}

void diff(vect_grid &one_vgrid, vect_grid &two_vgrid, vector<double>& D)
{
	unsigned int N=one_vgrid.value.size();
	for (unsigned int i = 0; i < N; i += 1)
	{
		D.push_back(one_vgrid.value[i]-two_vgrid.value[i]);
	}
}

int get_P(vector<double>& vA, vector<double>& vD, int MN, int IJ, vector<double>& vP)
{


	/*double a[MN][IJ];
	double d[MN][1];
	double s[MN*IJ];
	
	lapack_int info,m,n,lda,ldb,nrhs;
	long int i,j;
	
	double RCOND = -1;
	int RANK;
	int jvpt[MN*IJ];
	
	for(i=0;i<IJ;i++)
	{
		for(j=0;j<MN;j++)
		{
			a[j][i]=vA[i*(MN)+j];
		}
	}
	
	for(i=0;i<MN;i++)
	{
		d[i][0]=vD[i];
	}
	*/
	lapack_int info=0,m,n,lda,ldb,nrhs;
	int temp=vA.size();
	int temp2=vD.size();
	
	//cout << temp << endl;
	
	//double a[2856216];
	//double a[temp];
	//double b[temp2];
	
	double * a;
	double * b;
	
	a = (double*) malloc (sizeof(double)*(temp));
	if(a==NULL) exit (1);
	
	b = (double*) malloc (sizeof(double)*(temp2));
	if(b==NULL) exit (1);
	
	/*cout << vA.size() << "\t" << vD.size() << endl;
	cout << (sizeof(a)/sizeof(*a)) << endl;
	cout << MN << "\t" << IJ << endl;*/
		
	for(int i=0;i<vA.size();i++)
	{
		a[i]=vA[i];
	}
	
	for(int i=0;i<vD.size();i++)
	{
		b[i]=vD[i];
	}
	
	m=MN;
	n=IJ;
	nrhs=1;
	lda=m;
	ldb=m;
	
	//info=LAPACKE_dgels(LAPACK_ROW_MAJOR,'N',m,n,nrhs,a,lda,b,ldb);
	//info=LAPACKE_dgelss(LAPACK_ROW_MAJOR,m,n,nrhs,*a,lda,*d,ldb,s, RCOND, &RANK);
	//info=LAPACKE_dgelsy(LAPACK_ROW_MAJOR,m,n,nrhs,*a,lda,*d,ldb,jvpt, RCOND, &RANK);
	info = LAPACKE_dgels(LAPACK_COL_MAJOR, 'N', m, n, nrhs,a,lda,b,ldb);
	
	//cout << "hello" << endl;
	
	//cout << info << endl;
	
for(int i=0;i<n;i++)
   {
      //for(int j=0;j<nrhs;j++)
      //{
         //printf("%lf ",d[i][j]);
         vP[i]=b[i];
         //cout << d[i][j] << endl;
     // }
      //printf("\n");
   }
   
  // free(a);
   
   return(info);
}

double circ_average(vect_grid &data, double radius, double xcentre, double ycentre)
{
	double sum=0;
	double N=0;
	
	for (unsigned int i = 0; i < data.value.size(); i += 1)
	{
		if (pow(data.xpos[i]-xcentre,2) + pow(data.ypos[i]-ycentre,2) > pow(radius,2))
		{
			sum+=data.value[i];
			N++;
		}
	}
	
	return sum/N;
}
