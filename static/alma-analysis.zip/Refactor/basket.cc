// basket.cc - a program to implement basket-weaving

#include "stddef.h"
#include "stdfns.h" 
#include <lapacke.h>
#include "basketfns.h"
 
int main (int argc, char const* argv[])
{
	unsigned int headerlength=2, datastreams=8;
	string infile ("Data/X8b0c92_X114_map.dat");
	string dummy;
	char pattern = 'r'; // r=rectangular, c=circular, a=alternate circular (scans assigned alternately, rather than by gradient)
	unsigned int bw_order =  0 ; // polynomial order of basket weaving algorithm - 0,1 supported
	char print = 'r'; // r = regularised least squares, 'n' = none, print raw, 's' = print standard deviation of r's output
	int remove_gradient =1; // removes spatial gradient from final image - 
		
	double invR = 20; //~ 1.22 l/D in arcseconds
	double gridsize = 5;
	double xmin=0, xmax=0, ymin=0, ymax=0;
	double lambda=0.1;
	
	unsigned int datalength;
	
	int M,N,II=0,J=0;
	
	double temp, temp2;
	
	tempdata data, one, two;
	
	if (argc>1)
		sscanf( argv[1], "%c", &print );
		
	if (argc>2)
		sscanf( argv[2], "%c", &pattern );
		
	datalength = file_length(infile)-headerlength;
	
	ifstream fin; 
	fin.open(infile.c_str());
	if (fin.is_open()) {;}
	else  {cout << "Error opening file " << infile << endl;return -1;}
	
	for (unsigned int i = 0; i < headerlength; i += 1)
	{
		getline(fin, dummy);
	}
	
	for (unsigned int i = 0; i < datalength; i += 1)
	{
		
		fin >> temp;
		data.time.push_back(temp);
		
		fin >> temp;
		if (temp > xmax)
			{xmax=temp;}
		if (temp < xmin)
			{xmin=temp;}
		data.xpos.push_back(temp);
		
		fin >> temp;
		if (temp > ymax) 
			{ymax=temp;}
		if (temp < ymin)
			{ymin=temp;}
		data.ypos.push_back(temp);
		
		temp2=0;
		for (unsigned int j = 0; j < datastreams; j += 1)
		{
			fin >> temp;
			temp2+=temp;
		}
		data.value.push_back(temp2/datastreams);
	}
	
	fin.close();
	
	// Now, divide into two 	
	
	vector<unsigned int> edge_start;
	vector<unsigned int> edge_end;

	vector<unsigned int> zero_pos;

	bool in_edge=false;

	double xewidth=0.05*(xmax-xmin);
	double yewidth=0.05*(ymax-ymin);
	
	double rwidth=0.475*(xmax-xmin);
	double xcentre=(xmax+xmin)/2;
	double ycentre=(xmax+xmin)/2;
	
	double xlow=xmin+xewidth;
	double xhigh=xmax-xewidth;
	double ylow=ymin+yewidth;
	double yhigh=ymax-yewidth;
	
	if (pattern =='r')
	{
		for (unsigned int i = 0; i < datalength; i += 1)
		{
			if (in_edge==true && (data.xpos[i] > xlow && data.xpos[i] < xhigh) && (data.ypos[i] > ylow && data.ypos[i] < yhigh))
			{
				in_edge=false;
				edge_end.push_back(i);
			}

			if (in_edge==false && (data.xpos[i] < xlow || data.xpos[i] > xhigh || data.ypos[i] < ylow || data.ypos[i] > yhigh))
			{
				in_edge=true;
				edge_start.push_back(i);
			}
		}
	}
	
	else if (pattern =='c' || pattern == 'a')
	{
		for (unsigned int i = 0; i < datalength; i += 1)
		{
			if (in_edge==true && pow(data.xpos[i]-xcentre,2) + pow(data.ypos[i]-ycentre,2) < pow(rwidth,2) )
			{
				in_edge=false;
				edge_end.push_back(i);
			}

			if (in_edge==false && pow(data.xpos[i]-xcentre,2) + pow(data.ypos[i]-ycentre,2) > pow(rwidth,2) )
			{
				in_edge=true;
				edge_start.push_back(i);
			}
		}
	}
	
	else
	{
		cout << "Unrecognised pattern" << endl;
		return -1;
	}
		
	for (unsigned int i = 0; i < edge_end.size(); i += 1)
	{
		zero_pos.push_back((edge_end[i]+edge_start[i])*0.5);
	}
	
	if(pattern == 'r' || pattern == 'c')
	{
		for (unsigned int i = 0; i < zero_pos.size()-1; i += 1)
		{
			//test for sign of slope to assign to one of two scans
			temp=(data.ypos[zero_pos[i+1]]-data.ypos[zero_pos[i]])/(data.xpos[zero_pos[i+1]]-data.xpos[zero_pos[i]]);

			if (temp>=0)
			{
				for (unsigned int j = zero_pos[i]; j < zero_pos[i+1]; j += 1)
				{
					temp2=rand()%2;
					one.xpos.push_back(data.xpos[j]);
					one.ypos.push_back(data.ypos[j]);
					one.value.push_back(data.value[j]);
					one.scan_no.push_back(II);
					one.pos_in_scan.push_back(j-zero_pos[i]);
				}
				one.scan_size.push_back(zero_pos[i+1]-zero_pos[i]);
				II++;
			}
		
			else
			{
				temp2=rand()%100;
				two.scan_start.push_back(J);
				for (unsigned int j = zero_pos[i]; j < zero_pos[i+1]; j += 1)
				{
					two.xpos.push_back(data.xpos[j]);
					two.ypos.push_back(data.ypos[j]);
					two.value.push_back(data.value[j]);
					two.scan_no.push_back(J);
					two.pos_in_scan.push_back(j-zero_pos[i]);
				}
				two.scan_size.push_back(zero_pos[i+1]-zero_pos[i]);
				J++;
			}
		}
	}
	
	else if (pattern == 'a')
	{
		for (unsigned int i = 0; i < zero_pos.size()-1; i += 1)
		{
			//assign alternately to one of two scans
			if (i%2 == 0)
			{
				for (unsigned int j = zero_pos[i]; j < zero_pos[i+1]; j += 1)
				{
					temp2=rand()%2;
					one.xpos.push_back(data.xpos[j]);
					one.ypos.push_back(data.ypos[j]);
					one.value.push_back(data.value[j]);
					one.scan_no.push_back(II);
					one.pos_in_scan.push_back(j-zero_pos[i]);
				}
				one.scan_size.push_back(zero_pos[i+1]-zero_pos[i]);
				II++;
			}
		
			else if (i%2 == 1)
			{
				temp2=rand()%100;
				two.scan_start.push_back(J);
				for (unsigned int j = zero_pos[i]; j < zero_pos[i+1]; j += 1)
				{
					two.xpos.push_back(data.xpos[j]);
					two.ypos.push_back(data.ypos[j]);
					two.value.push_back(data.value[j]);
					two.scan_no.push_back(J);
					two.pos_in_scan.push_back(j-zero_pos[i]);
				}
				two.scan_size.push_back(zero_pos[i+1]-zero_pos[i]);
				J++;
			}
		}
	
	}

	// regrid each
	
	//create grids
	
	M = ((xmax-xmin)/gridsize) + 1;
	double xinterval=(xmax-xmin)/M;  
	
	N = ((ymax-ymin)/gridsize) + 1;
	double yinterval=(ymax-ymin)/N;
	 
	vect_grid one_vgrid;
	vect_grid two_vgrid;
	vect_grid plot_one, plot_two;
	vect_grid plot;
	
	int range=6;
	
	one_vgrid.init(M, N, xinterval, yinterval, xmin, ymin);
	two_vgrid.init(M, N, xinterval, yinterval, xmin, ymin);
	plot.init(M, N, xinterval, yinterval, xmin, ymin);
	plot_one.init(M, N, xinterval, yinterval, xmin, ymin);
	plot_two.init(M, N, xinterval, yinterval, xmin, ymin);
	
	//Now, fit each to its grid **** 1 ****
	
	fit_vgrid(M, N, xinterval, yinterval, xmin, ymin, two_vgrid, range, two, invR);
	fit_vgrid(M, N, xinterval, yinterval, xmin, ymin, one_vgrid, range, one, invR);
	fit_vgrid(M, N, xinterval, yinterval, xmin, ymin, plot, range, data, invR);
	
	if(print == 'n')
	{
		for (unsigned int i = 0; i < M; i += 1)
		{
			for (unsigned int j = 0; j < N; j += 1)
			{
				cout << plot.xpos[j+N*i] << "\t" << plot.ypos[j+N*i] << "\t" << (plot.value[j+N*i])*0.5 << endl;
			}
			cout << endl;
		}
		
		return 0;
	}
	
	// matrix of differences **** 2 ****
	
	vector<double> D;
	
	diff(one_vgrid, two_vgrid, D);
	
	// Create A, then populate
	
	vector<double> A; // an (II+J) * (M*N) matrix

	init_A_vgrid((1+bw_order)*(II+J)*(M*N), A);

	A_vgrid(M, N, xinterval, yinterval, xmin, ymin, A, one_vgrid, range, one, invR, 0,bw_order);

	A_vgrid(M, N, xinterval, yinterval, xmin, ymin, A, two_vgrid, range, two, invR, M*N*II,bw_order);
	
	if (bw_order == 0)
	{
		for (unsigned int j = 0; j < M*N; j += 1)
		{
			if (one_vgrid.weight[j]!=0)
			{
				for (unsigned int i = 0; i < II; i += 1)
				{		
					A[i*(M*N)+j]=A[i*(M*N)+j]/one_vgrid.weight[j];
				}
			}
		}
	
		for (unsigned int j = 0; j < M*N; j += 1)
		{
			if (two_vgrid.weight[j]!=0)
			{
				for (unsigned int i = II; i < II+J; i += 1)
				{
					A[i*(M*N)+j]=-1*A[i*(M*N)+j]/two_vgrid.weight[j];
				}
			}
		}
	}
	
	if(bw_order ==1)
	{
		for (unsigned int j = 0; j < M*N; j += 1)
		{
			if (one_vgrid.weight[j]!=0)
			{
				for (unsigned int i = 0; i < II; i += 1)
				{		
					A[(i*(M*N)+j)*2]=A[(i*(M*N)+j)*2]/one_vgrid.weight[j];
					A[(i*(M*N)+j)*2+1]=A[(i*(M*N)+j)*2+1]/one_vgrid.weight[j];
				}
			}
		}
	
		for (unsigned int j = 0; j < M*N; j += 1)
		{
			if (two_vgrid.weight[j]!=0)
			{
				for (unsigned int i = II; i < II+J; i += 1)
				{
					A[(i*(M*N)+j)*2]=A[(i*(M*N)+j)*2]/two_vgrid.weight[j];
					A[(i*(M*N)+j)*2+1]=A[(i*(M*N)+j)*2+1]/two_vgrid.weight[j];
				}
			}
		}
	}	
	
	if(print == 'r'|| print == 's')
	{
		vector<double> At,P ((bw_order+1)*(II+J)), C;
		int info;
		
		temp=sqrt(lambda);

		
		for (unsigned int i = 0; i < (bw_order+1)*(II+J); i += 1)
		{
			for (unsigned int j = 0; j < M*N; j += 1)
			{
				At.push_back(A[i*(M*N)+j]);
			}
			
			for (unsigned int j = 0; j < (bw_order+1)*(II+J); j += 1)
			{
				if(i==j)
					{At.push_back(temp);}
				else
					{At.push_back(0);}
			}
		}
		
		for (unsigned int i = 0; i < (bw_order+1)*(II+J); i += 1)
		{
			D.push_back(0);
		}
		
		info = get_P(At, D, M*N+(bw_order+1)*(II+J), (bw_order+1)*(II+J), P);
		
		for (unsigned int i = 0; i < M*N; i += 1)
		{
			temp=0;
		
			for (unsigned int j = 0; j < (bw_order+1)*II; j += 1)
			{
				temp+=one_vgrid.weight[i]*At[j*(M*N+II+J)+i]*P[j];
			}
		
			for (unsigned int j = II; j < (bw_order+1)*(II+J); j += 1)
			{
				temp-=two_vgrid.weight[i]*At[j*(M*N+II+J)+i]*P[j];
			}
		
			temp2=(bw_order+1)*(one_vgrid.weight[i] + two_vgrid.weight[i]);
		
			if(temp2 != 0)
				{C.push_back(temp/temp2);}
			else
				{C.push_back(0);}
		}
		
		for (unsigned int i = 0; i < M*N; i += 1)
		{
			plot.value[i]-=C[i];
		}
		
		//if you want to remove a gradient, use the following:
		
		if(remove_gradient == 1)
		{
			double av=0, xgrad=0, ygrad=0;
			temp=0;
			temp2=0;
		
			for (unsigned int i = 0; i < M*N; i += 1)
			{
				av+=plot.value[i];
			}
			av=av/(M*N);
		
			for (unsigned int i = 0; i < M*N; i += 1)
			{
				xgrad+=(plot.value[i]-av)*plot.xpos[i]/abs(plot.xpos[i]);
				temp+=abs(plot.xpos[i]);
				ygrad+=(plot.value[i]-av)*plot.ypos[i]/abs(plot.ypos[i]);
				temp2+=abs(plot.ypos[i]);
			}
			xgrad=xgrad/temp;
			ygrad=ygrad/temp2;
		
			for (unsigned int i = 0; i < M*N; i += 1)
			{
				plot.value[i]-=(xgrad*plot.xpos[i] + ygrad*plot.ypos[i]);
			}
		}
		if(print == 'r')
		{
			if (pattern == 'c')
			{
				temp = circ_average(plot, (xmax-xmin)/2, xcentre, ycentre);
		
				for (unsigned int i = 0; i < M*N; i += 1)
				{
					if (pow(plot.xpos[i]-xcentre,2) + pow(plot.ypos[i]-ycentre,2) > pow((xmax-xmin)/2,2))
					{
						plot.value[i]=temp;
					}
				}
			}
			
			for (unsigned int i = 0; i < M; i += 1)
			{
				for (unsigned int j = 0; j < N; j += 1)
				{				
					printf("%f\t%f\t%f\n",plot.xpos[j+N*i],plot.ypos[j+N*i],plot.value[j+N*i]-3.6);
				}
				cout << endl;
			}
		}
		
		if(print =='s')
		{
			if(pattern == 'c')
			{
				temp = circ_average(plot, (xmax-xmin)/2, xcentre, ycentre);
				temp2=0;
				int n=-1;
			
				for (unsigned int i = 0; i < M*N; i += 1)
				{
					if (pow(plot.xpos[i]-xcentre,2) + pow(plot.ypos[i]-ycentre,2) > pow(300,2))
					{
						temp2+=pow(plot.value[i]-temp, 2);
						n++;
					}
				}
				
				printf("Average: %f\nStandard Deviation: %F\n",temp,sqrt( temp2 / n ));
			}
			
			if (pattern == 'r')
			{
				temp=average(plot.value);
				temp2=0;
				
				for (unsigned int i = 0; i < M*N; i += 1)
				{
					temp2+=pow(plot.value[i]-temp, 2);
				}
				
				
				printf("Average: %f\nStandard Deviation: %F\n",temp,sqrt( temp2 / (M*N-1) ));
			}
		}
	}
}
