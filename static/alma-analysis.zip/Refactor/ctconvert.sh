# ctconvert.sh - converts csv to tab, plus appends no of lines

#!/bin/bash

file=OMC/OMC_DA47_hor

sed -e 's/,/\t/g' $file.csv > $file.dat
