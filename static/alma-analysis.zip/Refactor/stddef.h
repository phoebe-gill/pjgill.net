//stddef.h - a set of standard headers, definitions, etc for the Part III project

#include <cmath>
#include <iostream>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>
#include <fftw3.h>
//#include <lapacke.h>

# define M_PIl          3.141592653589793238462643383279502884L /* pi */

using namespace std;

struct metadata // used for storing scan metadata
{
	string Execblock_UID;
	string BDF_UID;
	unsigned int scan_no;
	unsigned int subscan_no;
	string antenna;
	double integration_time;
};

struct data // a single stream of data
{
	string name;
	metadata meta;
	unsigned int point_no;
	vector<double> time;
	vector<double> value;
};

class avdata // Here, we shall say T = a x + b
{
	public:
		double T_low;
		double T_big;
		vector<double> av_low;
		vector<double> av_big;
		vector<double> a;
		vector<double> b;
		vector<double> av_sky;
		vector<double> c; //T_CMB + T_atmosphere
		vector<double> G; //Gain
		vector<double> O; //T_antenna+T_receiver + Offset/Gain
		void readav(string, string, string, double, double, unsigned int);
	private:
};

struct tempdata
{
	vector<double> time;
	vector<double> xpos;
	vector<double> ypos;
	vector<double> value;
	vector<double> zvalue;
	vector<unsigned int> scan_start;  
	vector<unsigned int> scan_no;
	vector<unsigned int> scan_size;
	vector<unsigned int> pos_in_scan;
};

struct gridpoint
{
	double value;
	double weight;
	double vw;
	double xpos;
	double ypos;
};



class vect_grid
{
	public:
		vector<double> value;
		vector<double> weight;
		vector<double> vw;
		vector<double> xpos;
		vector<double> ypos;
		void init(int, int, double, double, double, double);
	private:
};
